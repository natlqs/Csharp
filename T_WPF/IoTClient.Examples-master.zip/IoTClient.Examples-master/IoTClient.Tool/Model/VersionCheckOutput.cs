﻿namespace IoTClient.Tool.Model
{
    public class VersionCheckOutput
    {
        /// <summary>
        /// 更新Code
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// 文件大小
        /// </summary>
        public int FileSize { get; set; }
    }
}
