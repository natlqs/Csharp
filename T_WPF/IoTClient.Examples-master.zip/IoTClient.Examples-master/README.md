
# IoTClient Tool 
![image](https://img.shields.io/github/license/alienwow/SnowLeopard.svg)
- IoTClient Tool是[IoTClient](https://github.com/zhaopeiym/IoTClient)库的桌面程序工具。
- IoTClient Tool主要作用：1、可用来测试Plc和相关协议的通信 2、可作为[IoTClient](https://github.com/zhaopeiym/IoTClient)库使用例子。
- 开发工具：Visual Studio 2019 
- QQ交流群：[700324594](https://jq.qq.com/?_wv=1027&k=tIRmmGbt)    
- IoTClient Tool [下载1](https://github.com/zhaopeiym/IoTClient.Examples/releases/download/1.0.3/IoTClient.exe) [下载2](https://download.haojima.net/api/IoTClient/Download) 

# IoTClient Tool效果图   
![image](https://user-images.githubusercontent.com/5820324/115138587-b7bebc80-a05f-11eb-9f7c-720a88bdca6e.png)  

![image](https://user-images.githubusercontent.com/5820324/115138592-bbeada00-a05f-11eb-9fc4-4b15a426cdb3.png)    

![image](https://user-images.githubusercontent.com/5820324/115138594-bd1c0700-a05f-11eb-8d4b-34a567669e3d.png)

![image](https://user-images.githubusercontent.com/5820324/115138596-bee5ca80-a05f-11eb-9878-9b05a4cfbc0b.png)  

![image](https://user-images.githubusercontent.com/5820324/115138597-c016f780-a05f-11eb-9d09-298a54f55266.png)  

![image](https://user-images.githubusercontent.com/5820324/115138600-c2795180-a05f-11eb-92b0-1a1d278c20c8.png)  

![image](https://user-images.githubusercontent.com/5820324/115138602-c3aa7e80-a05f-11eb-9cd7-be876735a26f.png)  

![image](https://user-images.githubusercontent.com/5820324/115138603-c5744200-a05f-11eb-9cdb-a222aa9b7b25.png)  

![image](https://user-images.githubusercontent.com/5820324/115138606-c73e0580-a05f-11eb-9ca1-5ece1bae8e71.png)  

![image](https://user-images.githubusercontent.com/5820324/115138607-c86f3280-a05f-11eb-83f1-d1706331406a.png) 
